/* package com.example.elijah_thomas_m31

class Item(
    val name: String,
    var id: Int,
    var quantity: Int,
    var price: Double,
    var description: String

)*/
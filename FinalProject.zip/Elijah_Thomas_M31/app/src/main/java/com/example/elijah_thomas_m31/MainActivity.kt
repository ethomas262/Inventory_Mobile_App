package com.example.elijah_thomas_m31

import android.os.Bundle

import androidx.activity.ComponentActivity



import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView



class MainActivity : ComponentActivity() {

    companion object {
        lateinit var sqLiteManager: SQLiteManager
    }


    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.home_page)
        val sqLiteManager = SQLiteManager.instanceOfDatabase(this)
        val adapter = ItemAdapter(this, Item.itemArrayList)


        val itemsList = mutableListOf(
            Item("Green Apple", 3, 4, 23.8, "Hello World!"),
            Item("Green Apple", 3, 4, 23.8, "Hello World!"),
            Item("Green Apple", 3, 4, 23.8, "Hello World!"),
            Item("Green Apple", 3, 4, 23.8, "Hello World!"),
        )

        val testItem = Item("Green Apple", 3, 4, 23.8, "Hello World!")
        sqLiteManager.addItemToDatabase(testItem)
        Item.itemArrayList.add(testItem)


        val rv: RecyclerView = findViewById(R.id.rvItems)
        rv.adapter = adapter
        rv.layoutManager = LinearLayoutManager(this)


    }

}



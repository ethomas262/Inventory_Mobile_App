package com.example.elijah_thomas_m31

import androidx.activity.ComponentActivity
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class SMS_Activity : ComponentActivity() {

    private val SMS_PERMISSION_CODE = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.sms_permission_layout)

        val requestPermissionButton: Button = findViewById(R.id.request_permission_button)
        val successMessage: TextView = findViewById(R.id.tvSuccessMessage)
        val deniedMessage: TextView = findViewById(R.id.tvDeniedMessage)
        val openSettingsButton: Button = findViewById(R.id.open_settings_button)

        requestPermissionButton.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    arrayOf(Manifest.permission.SEND_SMS), SMS_PERMISSION_CODE)
            } else {
                successMessage.visibility = View.VISIBLE
                deniedMessage.visibility = View.GONE
                openSettingsButton.visibility = View.GONE
            }
        }

        openSettingsButton.setOnClickListener {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            val uri = Uri.fromParts("package", packageName, null)
            intent.data = uri
            startActivity(intent)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        val successMessage: TextView = findViewById(R.id.tvSuccessMessage)
        val deniedMessage: TextView = findViewById(R.id.tvDeniedMessage)
        val openSettingsButton: Button = findViewById(R.id.open_settings_button)

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                successMessage.visibility = View.VISIBLE
                deniedMessage.visibility = View.GONE
                openSettingsButton.visibility = View.GONE
            } else {
                deniedMessage.visibility = View.VISIBLE
                openSettingsButton.visibility = View.VISIBLE
                successMessage.visibility = View.GONE
            }
        }
    }

}
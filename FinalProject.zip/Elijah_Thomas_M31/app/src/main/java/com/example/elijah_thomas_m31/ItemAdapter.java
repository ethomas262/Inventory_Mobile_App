package com.example.elijah_thomas_m31;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {
    private final Context context;
    private final List<Item> items;



    public ItemAdapter(Context context, List<Item> items) {
        this.context = context;
        this.items = items;
    }

    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        public TextView title;
        public TextView price;
        public TextView quantity;

        public ItemViewHolder(View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.itemName);
            price = itemView.findViewById(R.id.Item_Price);
            quantity = itemView.findViewById(R.id.Item_quantity);
        }
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_widget, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ItemViewHolder holder, int position) {
        // Access the itemView from the ViewHolder
        View itemView = holder.itemView;

        // Find the TextView and CheckBox by their ID
        TextView itemName = itemView.findViewById(R.id.itemName);
        TextView itemQuantity = itemView.findViewById(R.id.itemQuantity);
        Button incrementButton = itemView.findViewById(R.id.incrementItemButtton);
        Button decrementButton = itemView.findViewById(R.id.decrementItemButton);

        incrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                incrementItem(itemView, items.get(position));

            }
        });
        decrementButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                decrementItem(itemView, items.get(position));

            }
        });



        // Set the text for itemName and itemQuantity
        itemName.setText(items.get(position).getName());
        itemQuantity.setText(String.valueOf(items.get(position).getQuantity()));

        // Optionally, you can set the CheckBox state here if needed
        // itemSelected.setChecked(items.get(position).isSelected());
    }

    public void incrementItem(View itemView, Item item){

        // Find the TextView and CheckBox by their ID
        TextView itemQuantity = itemView.findViewById(R.id.itemQuantity);

        Item.incrementItem(item.getId());
        //MainActivity.sqLiteManager.incrementItemInDB(item.getId(), item.getQuantity() + 1);
        itemQuantity.setText(String.valueOf(item.getQuantity() + 1));
    }

    public void decrementItem(View itemView, Item item){

        // Find the TextView and CheckBox by their ID
        TextView itemQuantity = itemView.findViewById(R.id.itemQuantity);


        Item.decrementItem(item.getId());
        //MainActivity.sqLiteManager.decrementItemInDB(item);
        itemQuantity.setText(String.valueOf(item.getQuantity() - 1));

    }



    @Override
    public int getItemCount() {
        return items.size();
    }
}


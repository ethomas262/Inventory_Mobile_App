package com.example.elijah_thomas_m31

//import modules

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.ComponentActivity


import com.example.elijah_thomas_m31.databinding.LoginPageBinding

class LoginActivity : ComponentActivity() {
    private lateinit var binding : LoginPageBinding


    override fun onCreate(savedInstanceState: Bundle?){

        super.onCreate(savedInstanceState)
        binding = LoginPageBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.loginButton.setOnClickListener{
            if (binding.username.text.toString() == "user" && binding.password.text.toString() == "1234"){
                Toast.makeText(this, "Login Succesful!", Toast.LENGTH_SHORT).show()
            }
            else{
                Toast.makeText(this, "Login Failed!", Toast.LENGTH_SHORT).show()
            }

        }



    }


}